//
//  AddDebugSettingsExampleAppDelegate.h
//  AddDebugSettingsExample
//
//  Created by Andy Mroczkowski on 11/15/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AddDebugSettingsExampleViewController;

@interface AddDebugSettingsExampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    AddDebugSettingsExampleViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet AddDebugSettingsExampleViewController *viewController;

@end


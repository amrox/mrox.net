//
//  AddDebugSettingsExampleAppDelegate.m
//  AddDebugSettingsExample
//
//  Created by Andy Mroczkowski on 11/15/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import "AddDebugSettingsExampleAppDelegate.h"
#import "AddDebugSettingsExampleViewController.h"

@implementation AddDebugSettingsExampleAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
